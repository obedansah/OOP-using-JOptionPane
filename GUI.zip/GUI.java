import javax.swing.*;

public class GUI {
    /*
    Displaying Github is Open Source Platform  for all Programmers using GUI
     */
    public static void main(String[] args) {
        String Message="Github is Open Source Platform  for all Programmers"; //Message

        JOptionPane.showMessageDialog(null,Message); //Displaying message
    }
}
